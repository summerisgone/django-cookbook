# -*- coding: utf8 -*-
from settings import *
from os.path import join, dirname

ADMINS = (
    ('admin', 'info@example.com'),
)

MANAGERS = (
    ('manager', 'info@example.com'),
)

EMAIL_SUBJECT_PREFIX = '[hghkjgkghkj]'

PROJECT_DIR = dirname(__file__)

# DATABASES = 
SECRET_KEY = 'f4p0c9@^c&amp;zxfgw*h@6!=i3kzhx$7h1)swddm-^+$n-65c2l(_'
ROOT_URLCONF = 'hghkjgkghkj.auto_urls'

MEDIA_URL = '/media/'
MEDIA_ROOT = join(PROJECT_DIR, 'media')

UPLOAD_DIR = 'upload'
UPLOAD_URL = MEDIA_URL + UPLOAD_DIR

# ADMIN_MEDIA_PREFIX = '/media/admin/'

TEMPLATE_DIRS = [join(PROJECT_DIR, 'templates'),]

FIXTURE_DIRS = [join(PROJECT_DIR, 'fixtures'),]

# FCGI Server settings
FORCE_SCRIPT_NAME = ''

