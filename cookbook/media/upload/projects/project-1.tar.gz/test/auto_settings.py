# -*- coding: utf8 -*-
from settings import *
from os.path import join, dirname

ADMINS = (
    ('admin', 'info@example.com'),
)

MANAGERS = (
    ('manager', 'info@example.com'),
)

EMAIL_SUBJECT_PREFIX = '[test]'

PROJECT_DIR = dirname(__file__)

# DATABASES = 
SECRET_KEY = 'e4ep%01^m4@3a(3kcv9%s!dblvf*4p_*ue4hz=%9w@gsm2x9ls'
ROOT_URLCONF = 'test.auto_urls'

MEDIA_URL = '/media/'
MEDIA_ROOT = join(PROJECT_DIR, 'media')

UPLOAD_DIR = 'upload'
UPLOAD_URL = MEDIA_URL + UPLOAD_DIR

# ADMIN_MEDIA_PREFIX = '/media/admin/'

TEMPLATE_DIRS = [join(PROJECT_DIR, 'templates'),]

FIXTURE_DIRS = [join(PROJECT_DIR, 'fixtures'),]

# FCGI Server settings
FORCE_SCRIPT_NAME = ''

