# -*- coding: utf8 -*-
from settings import *
from os.path import join, dirname

ADMINS = (
    ('admin', 'info@example.com'),
)

MANAGERS = (
    ('manager', 'info@example.com'),
)

EMAIL_SUBJECT_PREFIX = '[test_project]'

PROJECT_DIR = dirname(__file__)

# DATABASES = 
SECRET_KEY = '5-b-$_8@r3kje^q6+)ta7h1posqg5ivti1kcev^)s=uj6w^n-2'
ROOT_URLCONF = 'test_project.auto_urls'

MEDIA_URL = '/media/'
MEDIA_ROOT = join(PROJECT_DIR, 'media')

UPLOAD_DIR = 'upload'
UPLOAD_URL = MEDIA_URL + UPLOAD_DIR

# ADMIN_MEDIA_PREFIX = '/media/admin/'

TEMPLATE_DIRS = [join(PROJECT_DIR, 'templates'),]

FIXTURE_DIRS = [join(PROJECT_DIR, 'fixtures'),]

# FCGI Server settings
FORCE_SCRIPT_NAME = ''

TEST = {u'dict': u'works', u'mode': u'test', u'yes': True}